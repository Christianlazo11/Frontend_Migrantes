export class ModelUser {
  id?: String;
  nombre?: String;
  apellido?: String;
  documento?: String;
  correo?: String;
  clave?: String;
  rol?: String;
  estado?: String;
}

// "r8P6IZSe-admin",

//   "apellido": "string",
//   "documento": "string",
//   "correo": "string",
//   "clave": "string",
//   "rol": "string"
