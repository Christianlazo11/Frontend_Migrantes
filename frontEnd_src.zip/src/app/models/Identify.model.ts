import { ModelDatos } from './datos.model';

export class ModelIdentify {
  datos?: ModelDatos;
  tk?: string;
  isLog: boolean = false;
}
