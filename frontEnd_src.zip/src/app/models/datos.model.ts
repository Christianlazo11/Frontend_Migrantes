export class ModelDatos {
  id?: String;
  name?: String;
  email?: String;
  rol?: String;
}
