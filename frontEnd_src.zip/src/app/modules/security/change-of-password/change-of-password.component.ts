import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-of-password',
  templateUrl: './change-of-password.component.html',
  styleUrls: ['./change-of-password.component.css']
})
export class ChangeOfPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
