export class ModelSurvey {
    id?: string;
    no_encuesta?: string;
    municipio?: string;
    direccion?: string;
    correo?: string;
    fijo_cel?: string;
    intencion?: string;
    intencion_permanecer?: string;
    tipo_doc?: string;
    ident_genero?: string;
    grupo_etnico?: string;
    usuarioId?: string;
    
   
  }